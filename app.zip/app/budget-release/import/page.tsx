'use client'

import { useState } from 'react'
import * as XLSX from 'xlsx'
import { createClient } from '@/lib/supabase/client'

export default function ImportBudgetPage() {
  const supabase = createClient()

  const [file, setFile] =
    useState<File | null>(null)

  const [rows, setRows] =
    useState<any[]>([])

  async function uploadFile() {
    if (!file) {
      alert('Select a file')
      return
    }

    try {
      const data =
        await file.arrayBuffer()

      const workbook = XLSX.read(data, {
        type: 'array',
      })

      const sheetName =
        workbook.SheetNames[0]

      const worksheet =
        workbook.Sheets[sheetName]

      const jsonData: any[] =
        XLSX.utils.sheet_to_json(
          worksheet
        )

      console.log('RAW DATA')
      console.log(jsonData)

      const mappedRows =
        jsonData.map((row: any) => {
          const values =
            Object.values(row)

          return {
            taluk:
              values[1]
                ?.toString()
                .trim(),

            head:
              values[2]
                ?.toString()
                .trim(),

            subHead:
              values[3]
                ?.toString()
                .trim(),

            annualBudget:
              Number(values[4]) || 0,

            installment1:
              Number(values[5]) || 0,

            installment2:
              Number(values[6]) || 0,

            installment3:
              Number(values[7]) || 0,

            installment4:
              Number(values[8]) || 0,

            totalReleased:
              Number(values[9]) || 0,
          }
        })

      console.table(mappedRows)

      setRows(mappedRows)

      console.log(
        'Before Supabase'
      )

      const { data: taluks } =
        await supabase
          .from('taluks')
          .select('id,name')

      const { data: heads } =
        await supabase
          .from('budget_heads')
          .select('id,head_code')

      const { data: subHeads } =
        await supabase
          .from('budget_sub_heads')
          .select(
            'id,sub_head_code'
          )

      console.log(
        'After Supabase'
      )

      console.log(
        'Taluks',
        taluks
      )

      console.log(
        'Heads',
        heads
      )

      console.log(
        'SubHeads',
        subHeads
      )

      const talukMap = new Map(
        taluks?.map((t) => [
          t.name
            .trim()
            .toLowerCase(),
          t.id,
        ])
      )

      const headMap = new Map(
        heads?.map((h) => [
          h.head_code
            .toString()
            .trim(),
          h.id,
        ])
      )

      const subHeadMap =
        new Map(
          subHeads?.map((s) => [
            s.sub_head_code
              .toString()
              .trim(),
            s.id,
          ])
        )

      // IMPORTANT:
      // DEFINE BEFORE USING

      const talukNameMap: any = {
        'ದೇವನಹಳ್ಳಿ':
          'devanahalli',

        'ಹೊಸಕೋಟೆ':
          'hoskote',

        'ನೆಲಮಂಗಲ':
          'nelamangala',

        'ದೊಡ್ಡಬಳ್ಳಾಪುರ':
          'doddaballapura',

        'ಬೆಂಗಳೂರು ಉತ್ತರ':
          'bangalore north',
      }

      const finalRows =
        mappedRows.map((r) => ({
          taluk_id:
            talukMap.get(
              talukNameMap[
                r.taluk
              ]
            ),

          budget_head_id:
            headMap.get(
              r.head
            ),

          budget_sub_head_id:
            subHeadMap.get(
              r.subHead
            ),

          installment_1:
            r.installment1,

          installment_2:
            r.installment2,

          installment_3:
            r.installment3,

          installment_4:
            r.installment4,
        }))

      console.log(
        'FINAL ROWS'
      )

      console.table(finalRows)
      const budgetRows = finalRows.map((row) => ({
  financial_year: '2025-26',

  month: 'APRIL',

  taluk_id: row.taluk_id,

  branch_id: null,

  budget_head_id:
    row.budget_head_id,

  budget_sub_head_id:
    row.budget_sub_head_id,

  installment_1:
    row.installment_1,

  installment_2:
    row.installment_2,

  installment_3:
    row.installment_3,

  installment_4:
    row.installment_4,

  amount:
    row.installment_1 +
    row.installment_2 +
    row.installment_3 +
    row.installment_4,

  remarks: 'Imported'
}))

console.table(budgetRows)
const { error } = await supabase
  .from('budget_releases')
  .insert(budgetRows)

if (error) {
  console.error(error)
  alert(error.message)
  return
}

alert(
  `${budgetRows.length} rows imported successfully`
)

      console.log(
        'Taluk Map',
        talukMap
      )

      console.log(
        'Head Map',
        headMap
      )

      console.log(
        'SubHead Map',
        subHeadMap
      )

      console.table(
        mappedRows.map((r) => ({
          excelTaluk:
            r.taluk,

          dbTalukId:
            talukMap.get(
              talukNameMap[
                r.taluk
              ]
            ) ||
            'NOT FOUND',
        }))
      )

      console.table(
        mappedRows.map((r) => ({
          excelHead:
            r.head,

          dbHeadId:
            headMap.get(
              r.head
            ) ||
            'NOT FOUND',

          excelSubHead:
            r.subHead,

          dbSubHeadId:
            subHeadMap.get(
              r.subHead
            ) ||
            'NOT FOUND',
        }))
      )
    } catch (error: any) {
      console.error(
        'FULL ERROR',
        error
      )

      alert(
        error?.message ||
          'Error reading Excel file'
      )
    }
  }

  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold mb-6">
        Import Budget Release
      </h1>

      <div className="flex items-center gap-4">
        <input
          type="file"
          accept=".xlsx,.xls"
          onChange={(e) =>
            setFile(
              e.target
                .files?.[0] ||
                null
            )
          }
        />

        <button
          onClick={uploadFile}
          className="bg-black text-white px-4 py-2 rounded"
        >
          Upload
        </button>
      </div>

      {rows.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">
            Excel Preview
          </h2>

          <div className="overflow-auto border rounded p-4 bg-gray-100">
            <pre>
              {JSON.stringify(
                rows.slice(
                  0,
                  10
                ),
                null,
                2
              )}
            </pre>
          </div>
        </div>
      )}
    </main>
  )
}